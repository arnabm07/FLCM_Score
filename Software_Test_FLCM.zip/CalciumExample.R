#Load the following libraries
library(MASS)
library(mgcv)
library(refund)
library(fda)
calcium <- read.csv("calcium.csv")
set.seed(10)
##########################################
#Sparse data, y calabs, x1 bmi, x2 caldiet
#testing effect of caldiet,
#data in long format data
##########################################
attach(calcium)
y <- calabs
x1 <- bmi
x2 <- caldiet
ID <- id
n = length(unique(id))
m = length(unique(age))
c <- min(age)
d <- max(age)
tage <- (age - c)/(d - c)
T <- list()
for (i in 1:n)
{
  ind <- which(id == i)
  T[[i]] <- tage[ind]
}
#Testing effcet of x2 in presence of x1
source('test.R')                                      ##Contains the R functions for testing
Pvalue <- FLCM.test.sparse2(y, x1, x2, T, n, ID, nbas = 7)     ##Function for testing in sparse 2 covariate case
#########################
#input in long format
#y,x1,x2 the response and two covariates
#T a list containing observation times of i'th individual in T[[i]]
#n: number of subjects
#ID: Subject id
#nbas: Number of basis functions to use
#Tests for effect of x2 in presence of x1
########################
Pvalue
########################
#Testing global effcet of x2 (Caldiet)
Pvalue <- FLCM.test.sparse1(y, x2, T, n, ID, nbas = 7) ##Function for testing sparse single covariate case
Pvalue
