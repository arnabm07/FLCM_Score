The following wrapper functions are used for testing.
######################################################################
### Dense data, single covariate testing###
function:FLCM.test1 
functioncall: (ymat, xmat, nbas)
input: (ymat, xmat, nbas)
ymat: the response matrix on dense grid.
xmat: the covarate matrix on dense grid.
nbas: Number of basis to use.
######################################################################
### Dense data, two covariate testing###
### Testing effect of x2 in presence of x1.
function:FLCM.test2 
functioncall: FLCM.test2(ymat, x1mat, x2mat, nbas)
input: (ymat, xmat, nbas)
ymat: the response matrix on dense grid
x1mat: the covarate matrix for x1 on dense grid.
x2mat: the covarate matrix for x2 on dense grid.
nbas: Number of basis to use.
######################################################################
### Sparse data, single covariate testing###
function: FLCM.test.sparse1 
functioncall: FLCM.test.sparse1(y, x, T, n, ID, nbas)
input: (y, x, T, n, ID, nbas)
y: the response in long format.
x: the covarate in long format.
T: A list contatining obeservation times for each subject.
n: Number of subjects.
ID: Subject identifiers (converted to 1:n).
nbas: Number of basis to use.
######################################################################
### Sparse data, two covariate testing###
### Testing effect of x2 in presence of x1.
function: FLCM.test.sparse2 
functioncall: FLCM.test.sparse2(y, x1, x2, T, n, ID, nbas)
input: (y, x, T, n, ID, nbas)
y: the response in long format.
x1: the covarate x1 in long format.
x2: the covarate x2 in long format.
T: A list contatining obeservation times for each subject.
n: Number of subjects.
ID: Subject identifiers (converted to 1:n).
nbas: Number of basis to use.
######################################################################
"FLCM_Testing.html" illustrates appication in dense data
######################################################################
"test.R","test.cpp" contains the main functions and needs to be sourced 
######################################################################
Illustrations for dense data in :  "gaitExample.R"
Illustrations for sparse data in : "CalciumExample.R"
calcium dataset included : "calcium.csv"        
######################################################################



