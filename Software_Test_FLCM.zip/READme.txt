# "test.R","test.cpp" contains the main functions and needs to be sourced 
# The following wrapper functions are used for testing.
########################################################################
# Dense data, single covariate testing function FLCM.test1 
########################################################################
# @ ymat= the response matrix on dense grid.
# @ xmat= the covarate matrix on dense grid.
# @ nbas= Number of basis to use.
functioncall : FLCM.test1(ymat, xmat, nbas)
########################################################################
# Dense data, two covariate testing function FLCM.test2
########################################################################
# Testing effect of x2 in presence of x1.
# @ ymat= the response matrix on dense grid.
# @ x1mat= the covarate1 matrix on dense grid.
# @ x2mat= the covarate2 matrix on dense grid.
# @ nbas= Number of basis to use.
functioncall : FLCM.test2(ymat, x1mat, x2mat, nbas)
########################################################################
# Sparse data, single covariate testing function FLCM.test.sparse1
########################################################################
# @y = the response in long format.
# @x = the covarate in long format.
# @T = A list contatining obeservation times for each subject.
# @n = Number of subjects.
# @ID = Subject identifiers (converted to 1:n).
# @nbas = Number of basis to use.
functioncall : FLCM.test.sparse1(y, x, T, n, ID, nbas)
########################################################################
# Sparse data, two covariate testing function FLCM.test.sparse2
########################################################################
# Testing effect of x2 in presence of x1.
# @y = the response in long format.
# @x1 = the covarate x1 in long format.
# @x2 = the covarate x2 in long format.
# @T = A list contatining obeservation times for each subject.
# @n = Number of subjects.
# @ID = Subject identifiers (converted to 1:n).
# @nbas = Number of basis to use.
functioncall : FLCM.test.sparse2(y, x1, x2, T, n, ID, nbas)
#######################################################################
"FLCM_Testing.html" illustrates appication in dense data
#######################################################################
Illustrations for dense data in :  "gaitExample.R", "CMRgdpExample.R"
#######################################################################



