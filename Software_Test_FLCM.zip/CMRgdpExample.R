#Load the following libraries
set.seed(1)
library(MASS)
library(mgcv)
library(refund)
library(fda)
library(gridExtra)
library(ggplot2)
library(tidyr)
library(openxlsx)
datagdp<-read.csv("gdppc.csv",header=T, check.names = F)
datachild<-read.csv("childmort.csv",header=T, check.names = F)
gdpcountry<- datagdp$country
######################################################
# getting 1960-2010 data
datagdpfinal<-datagdp[,c(1,162:212)]
indchild<-which(datachild$country%in%gdpcountry)
datachildfinal<-datachild[indchild,c(1,162:212)]
ymat<-datachildfinal[,2:52]
xmat<-datagdpfinal[,2:52]
######################################################
source('test.R') ##Contains the R functions for testing
###log transform Ymat
ymat<-log(ymat)
xmat<-log(xmat)
ymat<-as.matrix(ymat)
xmat<-as.matrix(xmat)
Pvalue <- FLCM.test1(ymat, xmat, nbas = 10) 
#Function for testing dense single covariate case
Pvalue
