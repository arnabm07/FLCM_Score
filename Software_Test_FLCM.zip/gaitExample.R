#Load the following libraries
library(MASS)
library(mgcv)
library(refund)
library(fda)
data(gait) ###Gait data in the FDA package
set.seed(1)
####################################
# Pre-processing Step:                #
# n=39, m=20                        	#
#dense data observed in equispaced grid
# knee = response, hip = covariate  	#
####################################
hip = knee = NULL
for (i in 1:20) {
  hip.temp = gait[i, , ][, 1]
  knee.temp = gait[i, , ][, 2]
  hip = cbind(hip, hip.temp)     	# dim(hip) = 39-by-20,Covariate
  knee = cbind(knee, knee.temp)		# dim(knee) = 39-by-20,Response
}
ymat <- knee
xmat <- hip
source('test.R')                            ##Contains the R functions for testing
Pvalue <- FLCM.test1(ymat, xmat, nbas = 14)          ##Function for testing dense single covariate case
Pvalue

##########################################################################
# Dense two covariate dense scenario, testing effcet of x2 in presence of x1
x1mat <- xmat
x2mat <- matrix(rnorm(39 * 20,5,2), nrow = 39, ncol = 20)    ## Generating a random x2 just for illustrating
Pvalue <- FLCM.test2(ymat, x1mat, x2mat, nbas = 14)   ##Function for testing dense two covariate case
Pvalue
